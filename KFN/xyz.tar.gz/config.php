 <?php
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $dbname='kfndb';
   $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
   
   if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
