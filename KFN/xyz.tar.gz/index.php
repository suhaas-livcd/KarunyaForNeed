﻿<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!-->
<html>
 <!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="Flatfy Free Flat and Responsive HTML5 Template ">
    <meta name="author" content="">

    <title>KFN – Karunya For Need</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Custom Google Web Font -->

    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!--
    <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Arvo:400,700' rel='stylesheet' type='text/css'>
        -->
    <!-- Custom CSS-->
    <link href="css/general.css" rel="stylesheet">

    <!-- Owl-Carousel -->
    <link href="css/custom.css" rel="stylesheet">
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">

    <!-- Magnific Popup core CSS file -->
    <link rel="stylesheet" href="css/magnific-popup.css">

    <script src="js/modernizr-2.8.3.min.js"></script>  <!-- Modernizr /-->
    <!--[if IE 9]>
        <script src="js/PIE_IE9.js"></script>
    <![endif]-->
    <!--[if lt IE 9]>
        <script src="js/PIE_IE678.js"></script>
    <![endif]-->
    <!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
    <![endif]-->

</head>

<body id="home" oncontextmenu="return false">

    <!-- Preloader -->
    <div id="preloader">
        <div id="status"></div>
    </div>

    <!-- FullScreen -->
    <div class="intro-header">
        <div class="col-xs-12 text-center abcen1">
            <h1 class="h1_home wow fadeIn" data-wow-delay="0.4s"><span style="color:gold">K</span>arunya <span style="color:lightskyblue">F</span>or <span style="color:lightsalmon">N</span>eed</h1>
            <h3 class="h3_home wow fadeIn" data-wow-delay="0.8s">A chance to grab the <span style="color:yellowgreen;font-weight:bold;">Need</span></h3>
            <ul class="list-inline intro-social-buttons">
                <li>
                    <a href="seller.php" class="btn  btn-lg mybutton_cyano wow fadeIn" data-wow-delay="1.0s"><span class="network-name">Be a Seller</span></a>
                </li>
                <li id="download">
                    <a href="buyer.php" class="btn  btn-lg mybutton_standard wow swing wow fadeIn" data-wow-delay="1.2s"><span class="network-name">Be a buyer</span></a>
                </li>
            </ul>
        </div>
        <!-- /.container -->
        <div class="col-xs-12 text-center abcen wow fadeIn">
            <div class="button_down">
                <a class="imgcircle wow bounceInUp" data-wow-duration="1.5s" href="#whatis"> <img class="img_scroll" src="img/icon/circle.png" alt=""> </a>
            </div>
        </div>
    </div>


    <!-- NavBar-->
    <nav class="navbar-default" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#home"><i class="fa fa-opencart"></i>KFN</a>
            </div>

            <div class="collapse navbar-collapse navbar-right navbar-ex1-collapse">
                <ul class="nav navbar-nav">

                    <li class="menuItem"><a href="#whatis">What is?</a></li>
                    <li class="menuItem"><a href="#screen">Categories</a></li>
                    <li class="menuItem"><a href="#credits">Development</a></li>
                    <li class="menuItem"><a href="#contact">Contact</a></li>
                </ul>
            </div>

        </div>
    </nav>

    <!-- What is -->
    <div id="whatis" class="content-section-b" style="border-top: 0">
        <div class="container">

            <div class="col-md-6 col-md-offset-3 text-center wrap_title">
                <h2>What is?</h2>
                <p class="lead" style="margin-top:0">A glimpse</p>

            </div>

            <div class="row">

                <div class="col-sm-4 wow fadeInDown text-center">
                    <img class="img-thumbnail wow swing" src="img/icon/money-bag.svg" alt="Generic placeholder image">
                    <h3>Be a Seller</h3>
                    <p class="lead">A chance to host your product and see your customers bid. </p>

                    <!-- <p><a class="btn btn-embossed btn-primary view" role="button">View Details</a></p> -->
                </div><!-- /.col-lg-4 -->

                <div class="col-sm-4 wow fadeInDown text-center">
                    <img class="wow pulse" height="250px;" src="img/icon/computer.svg" alt="Generic placeholder image">
                    <h3>Be a Dev</h3>
                    <p class="lead">Wanna be a part of the Karunya Online Marketting involving Data Analytics and managing the application. </p>
                    <!-- <p><a class="btn btn-embossed btn-primary view" role="button">View Details</a></p> -->
                </div><!-- /.col-lg-4 -->

                <div class="col-sm-4 wow fadeInDown text-center">
                    <img class="img-thumbnail wow swing" src="img/icon/shopping-bags.svg" alt="Generic placeholder image">
                    <h3>Be a Buyer</h3>
                    <p class="lead">Fullfill your need by bidding among your peers. </p>
                    <!-- <p><a class="btn btn-embossed btn-primary view" role="button">View Details</a></p> -->
                </div><!-- /.col-lg-4 -->

            </div><!-- /.row -->

            <div class="row tworow hidden" >

                <div class="col-sm-4  wow fadeInDown text-center">
                    <img class="rotate" src="img/icon/laptop.svg" alt="Generic placeholder image">
                    <h3>Responsive</h3>
                    <p class="lead">Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorilla congolium sic ad nauseum. </p>
                    <!-- <p><a class="btn btn-embossed btn-primary view" role="button">View Details</a></p> -->
                </div><!-- /.col-lg-4 -->

                <div class="col-sm-4 wow fadeInDown text-center">
                    <img class="rotate" src="img/icon/map.svg" alt="Generic placeholder image">
                    <h3>Google</h3>
                    <p class="lead">Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorilla congolium sic ad nauseum. </p>
                    <!-- <p><a class="btn btn-embossed btn-primary view" role="button">View Details</a></p> -->
                </div><!-- /.col-lg-4 -->

                <div class="col-sm-4 wow fadeInDown text-center">
                    <img class="rotate" src="img/icon/browser.svg" alt="Generic placeholder image">
                    <h3>Bootstrap</h3>
                    <p class="lead">Epsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorilla congolium sic ad nauseum. </p>
                    <!-- <p><a class="btn btn-embossed btn-primary view" role="button">View Details</a></p> -->
                </div><!-- /.col-lg-4 -->

            </div><!-- /.row -->
        </div>
    </div>



    <!-- Screenshot -->
    <div id="screen" class="content-section-b">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center wrap_title ">
                    <h2>Categories</h2>
                    <p class="lead" style="margin-top:0">Know your Products</p>
                </div>
            </div>
            <div class="row wow bounceInUp">
                <div id="owl-demo" class="owl-carousel">

                    <a href="img/slide/1.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/1.jpg" alt="Bicycle">
                        </div>
                    </a>

                    <a href="img/slide/2.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/2.jpg" alt="Owl Image">
                        </div>
                    </a>

                    <a href="img/slide/3.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/3.jpg" alt="Owl Image">
                        </div>
                    </a>

                    <a href="img/slide/4.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/4.jpg" alt="Owl Image">
                        </div>
                    </a>

                    <a href="img/slide/5.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/5.jpg" alt="Owl Image">
                        </div>
                    </a>

                    <a href="img/slide/6.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/6.jpg" alt="Owl Image">
                        </div>
                    </a>
                    
                     <a href="img/slide/7.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/7.jpg" alt="Owl Image">
                        </div>
                    </a>
                    
                     <a href="img/slide/8.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/8.jpg" alt="Owl Image">
                        </div>
                    </a>
                    
                     <a href="img/slide/9.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/9.jpg" alt="Owl Image">
                        </div>
                    </a>
                    
                     <a href="img/slide/10.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/10.jpg" alt="Owl Image">
                        </div>
                    </a>
                    
                     <a href="img/slide/11.jpg" class="image-link">
                        <div class="item">
                            <img class="img-responsive img-rounded" src="img/slide/11.jpg" alt="Owl Image">
                        </div>
                    </a>
                    
                </div>
            </div>
        </div>


    </div>

    

    <!-- Credits -->
    <div id="credits" class="content-section-a">
        <div class="container">
            <div class="row">

                <div class="col-md-6 col-md-offset-3 text-center wrap_title">
                    <h2 class="wow pulse">Dev <i class="fa fa-code"></i></h2>
                    <p class="lead" style="margin-top:0">We love to code</p>
                </div>

                <div class="col-sm-6  block wow bounceIn">
                    <div class="row">
                        <div class="col-md-4  ">
                            <!--
                            <i class="fa fa-user fa-4x "></i>-->
                            <img class="img-circle" src="img/Potrait/anithamam.jpg" height="120px" />
                        </div>
                        <div class="col-md-8 box-ct">
                            <h3> Guide </h3>
                            <a href="http://karunya.edu/cse/faculty/faculty.php?id=14"><p> Anitha J</p></a>
                            
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 block wow bounceIn">
                    <div class="row">
                        <div class="col-md-4  ">
                            <!--
                            <i class="fa fa-user fa-4x "> </i>-->
                            <img class="img-circle" src="img/Potrait/suhaas.JPG" height="120px;" width="120px;" alt="image not loaded"/>
                        </div>
                        <div class="col-md-8 box-ct">
                            <h3>Student </h3>
                            <p>G Suhaas Srinivas</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row tworow">
                <div class="col-sm-6  block wow bounceIn">
                    <div class="row">
                        <div class="col-md-4  ">
                            <!--
                            <i class="fa fa-building-o fa-4x "> </i>-->
                            <img class="img-circle" src="img/Potrait/Octalian.png" height="120px" />
                        </div>
                        <div class="col-md-8 box-ct">
                            <h3> Partner Company </h3>
                            <p> Octalian Media . </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 block wow bounceIn">
                    <div class="row">
                        <div class="col-md-4  ">
                            <img class="img-circle" src="img/Potrait/images.png" height="120px" />
                        </div>
                        <div class="col-md-8 box-ct">   
                            <h3>Univeristy</h3>
                            <p>School of Computer Science & Technology</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact -->
    <div id="contact" class="content-section-c ">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center white">
                    <h2>Contact Us</h2>
                    <p class="lead" style="margin-top:0">Feel Free to Write</p>
                </div>
                <div class="col-md-6 col-md-offset-3 text-center">
                    <div class="mockup-content">
                        <div class="morph-button wow pulse morph-button-inflow morph-button-inflow-1">
                            <button type="button"><span>Message Us</span></button>
                            <div class="morph-content">
                                <div>
                                    <div class="content-style-form content-style-form-4 ">
                                        <h2 class="morph-clone">Write Your Message</h2>
                                        <form role="form" action="" method="post">
                                            <p><input type="text" class="form-control" name="InputName" id="InputName" placeholder="Name" required></p>
                                            <p><input type="text" class="form-control" id="InputEmail" name="InputEmail" placeholder="Enter Email" required></p>
                                            <p><textarea name="InputMessage" id="InputMessage" class="form-control" rows="5" placeholder="Write your Message"></textarea></p>
                                            <p><input type="submit" name="submit" id="submit" value="Submit" class="btn wow tada btn-embossed btn-primary"></p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-md-offset-3">
                    <div class="col-md-6  col-sm-6 address col-xs-12 text-left white">
                        <h3>Location</h3>
                        <a href="http://karunya.edu/" style="color:lawngreen;">Karunya University</a><br>
                        Karunya Nagar,<br>
                        Coimbatore - 641114,<br>
                        Tamil Nadu, India.<br>
                    </div>
                    <div class="col-md-6  col-sm-6 col-xs-12 address text-right white">
                        <h3>Social</h3>
                        <li class="social">
                            <a href="#" class="white"><i class="fa fa-facebook-square fa-size"> </i></a>
                            <a href="#" class="white"><i class="fa  fa-twitter-square fa-size"> </i> </a>
                            <a href="#" class="white"><i class="fa fa-google-plus-square fa-size"> </i></a>
                            <a href="#" class="white"><i class="fa fa-flickr fa-size"> </i> </a>
                        </li>
                    </div>
                </div>

            </div>
        </div>>
    </div>

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/script.js"></script>
    <!-- StikyMenu -->
    <script src="js/stickUp.min.js"></script>
    <script type="text/javascript">
        jQuery(function ($) {
            $(document).ready(function () {
                $('.navbar-default').stickUp();

            });
        });

    </script>
    <!-- Smoothscroll -->
    <script type="text/javascript" src="js/jquery.corner.js"></script>
    <script src="js/wow.min.js"></script>
    <script>
        new WOW().init();
    </script>
    <script src="js/classie.js"></script>
    <script src="js/uiMorphingButton_inflow.js"></script>
    <!-- Magnific Popup core JS file -->
    <script src="js/jquery.magnific-popup.js"></script>
    
     
</body>

</html>
