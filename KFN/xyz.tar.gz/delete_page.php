<?php
$id = $_POST['delete_id'];
$query = "delete from gallery where id = $id";
?>

